"""Review probes for tutorials/DIMER_MultiModel_Depth_Estimation_Workshop.ipynb (DEP findings).

CPU-only, no model weights, no network. Each probe reports ``defect_present`` for one finding so the same
script can be re-run against a fixed revision. Usage:

    python run_probes.py <notebook.ipynb> <results.json>

Evidence basis: direct execution of the notebook's carried worker (``workshop.py``) and carried
``depth_reference``/``zoe_reference`` modules on synthetic RGB-D data (labelled "direct execution, CPU,
synthetic"), plus static source inspection of the notebook cells (labelled "source inspection").
"""

from __future__ import annotations

import ast
import importlib
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

NB = Path(sys.argv[1])
OUT = Path(sys.argv[2])
notebook = json.loads(NB.read_text(encoding="utf-8"))
cells = notebook["cells"]
src = ["".join(c["source"]) for c in cells]
md = "\n".join(s for s, c in zip(src, cells) if c["cell_type"] == "markdown")
code = [(i, s, c) for i, (s, c) in enumerate(zip(src, cells)) if c["cell_type"] == "code"]

carried_cell = next(s for s in src if "CARRIED_FILES = " in s)
body = ast.parse(carried_cell).body
assigns = {n.targets[0].id: n.value for n in body if isinstance(n, ast.Assign)}
CARRIED = ast.literal_eval(assigns["CARRIED_FILES"])
work = Path(tempfile.mkdtemp(prefix="dep_probe_"))
for name, text in CARRIED.items():
    path = work / "carried" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode("utf-8"))
sys.path.insert(0, str(work / "carried"))
workshop = importlib.import_module("workshop")
results: list[dict] = []


def record(pid: str, finding: str, defect: bool, basis: str, detail) -> None:
    results.append({"probe": pid, "finding": finding, "defect_present": bool(defect), "basis": basis, "detail": detail})
    print(pid, finding, "DEFECT" if defect else "clear", flush=True)


def make_byod(root: Path, n_per_role=(6, 2, 4)) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)
    records = []
    index = 0
    for role, count in zip(("train", "validation", "test"), n_per_role):
        for k in range(count):
            rid = f"{role[:2]}{k:02d}"
            h, w = 48, 64
            Image.fromarray(rng.integers(0, 255, (h, w, 3), dtype=np.uint8)).save(root / f"{rid}.png")
            depth = (1.0 + 4.0 * rng.random((h, w))).astype(np.float32)
            np.save(root / f"{rid}_depth.npy", depth, allow_pickle=False)
            np.save(root / f"{rid}_mask.npy", np.ones((h, w), dtype=bool), allow_pickle=False)
            records.append({"id": rid, "image": f"{rid}.png", "depth": f"{rid}_depth.npy", "mask": f"{rid}_mask.npy",
                            "group_id": f"{role}-g{k % 2}", "role": role, "domain": "indoor"})
            index += 1
    manifest = {"units": "metres", "records": records}
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return manifest


def refusal(directory: Path, run_prepare: bool = True) -> str:
    """Return the first refusal message from load_byod (+ prepare, the per-record source contract)."""
    try:
        workshop.load_byod(directory)
        if run_prepare:
            child = work / "child" / directory.name
            shutil.rmtree(child, ignore_errors=True)
            workshop.prepare(child, str(directory))
        return ""
    except ValueError as exc:
        return str(exc)


# P01 / DEP-M1 — BYOD: valid synthetic data passes; refusals must name the failing record/file.
base = work / "byod_ok"
manifest = make_byod(base)
ok_message = refusal(base)
matrix = {}


def variant(name: str, mutate) -> Path:
    target = work / f"byod_{name}"
    shutil.copytree(base, target)
    data = json.loads((target / "manifest.json").read_text())
    mutate(target, data)
    (target / "manifest.json").write_text(json.dumps(data), encoding="utf-8")
    return target


def low_coverage(target: Path, data: dict) -> None:  # record 7 (te... no: index 7 = va01) has 2% valid pixels
    mask = np.zeros((48, 64), dtype=bool)
    mask[:1, :61] = True
    np.save(target / data["records"][7]["mask"], mask, allow_pickle=False)


def missing_depth(target: Path, data: dict) -> None:
    (target / data["records"][5]["depth"]).unlink()


def float64_depth(target: Path, data: dict) -> None:
    rec = data["records"][3]
    np.save(target / rec["depth"], np.load(target / rec["depth"]).astype(np.float64), allow_pickle=False)


def no_group(target: Path, data: dict) -> None:
    data["records"][9].pop("group_id")


def crossing(target: Path, data: dict) -> None:
    data["records"][11]["group_id"] = "train-g0"


cases = {
    "low_coverage_record_7": (low_coverage, "va01"),
    "missing_depth_record_5": (missing_depth, "tr05"),
    "float64_depth_record_3": (float64_depth, "tr03"),
    "missing_group_record_9": (no_group, "te01"),
    "group_crosses_roles_record_11": (crossing, "train-g0"),
}
named = {}
for name, (mutate, needle) in cases.items():
    message = refusal(variant(name, mutate))
    matrix[name] = message
    named[name] = bool(message) and needle in message
record(
    "P01",
    "DEP-M1",
    (ok_message != "") or not all(named.values()) or "records[0]" in matrix["low_coverage_record_7"],
    "direct execution (CPU, synthetic RGB-D; load_byod + prepare of the carried worker)",
    {"valid_byod_refusal": ok_message, "refusals": matrix, "names_failing_record_or_group": named},
)

# P02 / DEP-M1 — BYOD contract stated before data is supplied (DAT12) and results shown (transfer).
byod_md = next((s for s, c in zip(src, cells) if c["cell_type"] == "markdown" and "your own labelled" in s.lower()), "")
byod_code = next((s for s in src if "RUN_BYOD" in s), "")
stated = {
    "id_pattern": "A-Za-z0-9" in byod_md,
    "coverage_5_percent": "5%" in byod_md or "5 %" in byod_md,
    "depth_range": "350" in byod_md,
    "exif": "EXIF" in byod_md,
    "example_manifest": '"records"' in byod_md,
    "how_to_supply_in_colab": "Files" in byod_md or "Drive" in byod_md,
    "data_stays_local": "leave" in byod_md.lower() or "not sent" in byod_md.lower() or "not transmitted" in byod_md.lower(),
    "byod_results_displayed": "summary.md" in byod_code,
}
report_src = CARRIED["workshop.py"]
two_scene_line_unconditional = re.search(r'\n\s+"Default test views cover only two scenes', report_src) is not None
record("P02", "DEP-M1", not all(stated.values()) or two_scene_line_unconditional, "source inspection",
       {"stated": stated, "byod_summary_claims_default_two_scenes": two_scene_line_unconditional})

# P03 / DEP-m1 — infrastructure cells labelled and collapsed (GDL11).
infra = [i for i, s, c in code if i <= 4]
labelled = {i: src[i].lstrip().startswith("# @title Infrastructure") and cells[i].get("metadata", {}).get("cellView") == "form"
            for i in infra}
record("P03", "DEP-m1", not all(labelled.values()), "source inspection",
       {"infrastructure_cells": labelled, "carried_cell_chars": len(carried_cell)})

# P04 / DEP-m2 — scoring logic readable from a learner-facing cell.
shows = any(("def score" in s or "'score'" in s or '"score"' in s) and "workshop.py" in s and "CARRIED_FILES" not in s
            for _, s, _ in code)
record("P04", "DEP-m2", not shows, "source inspection", {"learner_cell_prints_scoring_source": shows})

# P05 / DEP-m3 — training evidence shown: per-epoch pre-restoration weight change; honest figure labels.
depth_cell = next(s for s in src if "run_stage('depth')" in s)
shows_delta = "max_weight_delta_before_selection" in depth_cell
fig_fn = getattr(workshop, "select_figures", None)
if fig_fn is None:
    honest = "best adaptation delta" not in report_src or "no adaptation change" in report_src
else:
    rows = [{"id": f"t{i}", "abs_rel_delta": 0.0} for i in range(4)]
    labels = fig_fn([{"id": f"t{i}", "domain": "indoor"} for i in range(4)], rows)
    honest = not any("best" in v or "worst" in v for v in labels.values())
record("P05", "DEP-m3", not (shows_delta and honest), "source inspection + direct execution of select_figures",
       {"depth_cell_shows_pre_restoration_deltas": shows_delta, "zero_change_labels_honest": honest})

# P06 / DEP-m4 — download route and resource measurements visible.
final = next(s for s in src if "run_stage('report')" in s)
uses_filelink_only = "FileLink" in final and "Files" not in final
shows_peak = "peak_gpu_bytes" in final
shows_disk = "disk" in final.lower()
filelink_href = None
try:
    from IPython.display import FileLink

    probe_file = work / "content" / "x.zip"
    probe_file.parent.mkdir(parents=True, exist_ok=True)
    probe_file.write_bytes(b"x")
    filelink_href = re.search(r"href='([^']+)'", FileLink(str(probe_file))._repr_html_()).group(1)
except Exception as exc:  # noqa: BLE001
    filelink_href = f"unavailable: {exc}"
record("P06", "DEP-m4", uses_filelink_only or not (shows_peak and shows_disk), "source inspection + IPython FileLink",
       {"final_cell_filelink_without_files_pane_instruction": uses_filelink_only, "shows_peak_gpu": shows_peak,
        "shows_disk": shows_disk, "filelink_href_for_absolute_path": filelink_href})

# P07 / DEP-m5 — unlabelled image: limits stated, actionable refusals, preview produced.
unl_md = next((s for s, c in zip(src, cells) if c["cell_type"] == "markdown" and "without a reference" in s), "")
big = work / "phone.jpg"
Image.new("RGB", (4032, 3024), "grey").save(big)
rot = work / "rotated.jpg"
exif = Image.Exif()
exif[274] = 6
Image.new("RGB", (640, 480), "grey").save(rot, exif=exif)
messages = {}
for label, path in (("4032x3024", big), ("exif_orientation_6", rot)):
    try:
        workshop.bounded_image(path)
        messages[label] = ""
    except ValueError as exc:
        messages[label] = str(exc)
infer_src = ast.get_source_segment(report_src, next(n for n in ast.parse(report_src).body if getattr(n, "name", "") == "infer"))
checks = {
    "limits_stated_in_section": "2048" in unl_md,
    "size_message_names_file_and_size": "phone.jpg" in messages["4032x3024"] and "4032" in messages["4032x3024"],
    "exif_message_not_about_references": "reference" not in messages["exif_orientation_6"],
    "adapter_prerequisite_checked": "adapter" in infer_src and "exists" in infer_src,
    "preview_png_written": ".png" in infer_src,
}
record("P07", "DEP-m5", not all(checks.values()), "direct execution (bounded_image) + source inspection",
       {"checks": checks, "messages": messages})

# P08 / DEP-m6 — terminology (GDL15) and glossary (GDL6).
learner_workshop = [m.group(0) for m in re.finditer(r"[^\n]{0,30}(?<![`\w])workshop(?![`\w])[^\n]{0,30}", md, re.I)]
summary_heading_workshop = "Depth workshop measured results" in report_src
glossary = re.search(r"#+\s*(Key terms|Glossary)", md) is not None
neck_defined = re.search(r"\*\*neck\*\*|neck\W+the ", md, re.I) is not None
record("P08", "DEP-m6", bool(learner_workshop) or summary_heading_workshop or not glossary or not neck_defined,
       "source inspection", {"workshop_in_markdown": learner_workshop, "summary_heading_says_workshop": summary_heading_workshop,
                             "glossary": glossary, "neck_defined": neck_defined})

# P09 / DEP-m7 — a learner-chosen change exists (GDL10) and reaches the computation.
params = sorted({m.group(1) for _, s, _ in code for m in re.finditer(r"^(\w+)\s*=.*# @param", s, re.M)})
try:
    workshop.brightness(Image.new("RGB", (8, 8), "grey"), 0.8)
    accepts_custom = True
except ValueError:
    accepts_custom = False
own_stage = "own_activity" in report_src
record("P09", "DEP-m7", not (accepts_custom and own_stage and any("FACTOR" in p for p in params)),
       "direct execution (brightness) + source inspection",
       {"form_fields": params, "brightness_accepts_0.8": accepts_custom, "own_activity_stage": own_stage})

OUT.write_text(json.dumps({"notebook": str(NB.name), "probes": results,
                           "open_defects": sorted({r['finding'] for r in results if r['defect_present']})}, indent=2),
               encoding="utf-8")
print("open:", sorted({r["finding"] for r in results if r["defect_present"]}))
