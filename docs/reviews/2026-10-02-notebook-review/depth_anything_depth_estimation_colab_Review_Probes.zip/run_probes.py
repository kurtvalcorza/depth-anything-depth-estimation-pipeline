"""Probes for the Notebook Review Framework v1 review of
tutorials/depth_anything_depth_estimation_colab.ipynb (DAC-*), reviewed SHA 5f6b516c.

CPU-only direct execution of the committed notebook's code cells in one interpreter, in cell order,
from a scratch working directory whose weights/ snapshot and weights/diode-sample/ corpus cache are
hard links of already-digest-verified local copies (the notebook re-hashes every file before use).
DIMER_NOTEBOOK_CI_PREINSTALLED=1 skips the in-kernel pip install (cell 3), so the restart behaviour is
NOT exercised here; it is taken from the archived Kaggle record. Interpreter: the build venv
dimer-next16 (CPython 3.12.10) whose torch/torchvision/transformers/numpy/pillow/safetensors/hub versions
equal the notebook's PINS (torchaudio not imported by the notebook), CUDA hidden. A first attempt in the conda
env eo-notebook-test (torch 2.13.0+cpu) crashed natively in numpy.linalg.lstsq (0xc06d007f, an environment
DLL fault unrelated to the notebook) and was discarded.

Usage: python run_probes.py <notebook.ipynb> <workdir> <results.json> [part2]
  part2 (second invocation, no model): P4 BYOD group-count boundary through cell 13's BYOD branch with
  zips of 8 DIODE views spread over 1, 3 and 4 groups; results go to <results>.part2.json
Parts:
  P0 static: blob id, cell inventory, doubled-brace markers in learner-facing markdown
  P1 clean default: cells 3..23 at the documented defaults
  P2 active learning: the documented optional experiment LEARNING_RATE = 3e-5, applied by editing
     cell 19 and re-running cells 19, 21, 23 (the cells downstream of the change)
  P3 BYOD / recovery: USE_BYOD = True through a google.colab.files.upload shim (valid zip built from
     DIODE training views, then three invalid inputs), followed by Section 6 (cell 17) as the
     "re-run from that cell" instruction implies, with the already-adapted pipe
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB, WORK, OUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
PART2 = len(sys.argv) > 4 and sys.argv[4] == 'part2'
if PART2:
    OUT = OUT.with_suffix('.part2.json')
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ.setdefault('KMP_DUPLICATE_LIB_OK', 'TRUE')
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
results: dict = {'started': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}


def save() -> None:
    OUT.write_text(json.dumps(results, indent=1, default=str), encoding='utf-8')


nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
src = {i: ''.join(c['source']) for i, c in enumerate(cells)}

# ---------------- P0 static ----------------
raw = NB.read_bytes()
blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
md_braces = {i: re.findall(r'\{\{[^}]*\}\}', s) for i, s in src.items() if cells[i]['cell_type'] == 'markdown'}
results['P0_static'] = {
    'blob': blob,
    'n_cells': len(cells),
    'code_cells': [i for i, c in enumerate(cells) if c['cell_type'] == 'code'],
    'metadata_dimer': nb['metadata'].get('dimer'),
    'markdown_doubled_braces': {k: v for k, v in md_braces.items() if v},
    'cellView_form_cells': [i for i, c in enumerate(cells) if c.get('metadata', {}).get('cellView') == 'form'],
    'embedded_module_chars': sum(len(src[i]) for i, c in enumerate(cells) if 'embedded_module' in json.dumps(c.get('metadata', {}))),
    'learner_markdown_mentions': {
        'restart': [i for i, s in src.items() if cells[i]['cell_type'] == 'markdown' and 'restart' in s.lower()],
        'troubleshoot': [i for i, s in src.items() if 'troubleshoot' in s.lower()],
        'predict_before_run': [i for i, s in src.items() if cells[i]['cell_type'] == 'markdown' and re.search(r'\bpredict (what|whether|which|how)', s, re.I)],
        'infrastructure_label': [i for i, s in src.items() if cells[i]['cell_type'] == 'markdown' and 'infrastructure' in s.lower()],
    },
}
save()

# ---------------- execution harness ----------------
os.chdir(WORK)
ns: dict = {'__name__': '__main__'}
UPLOAD: dict = {}
colab = types.ModuleType('google.colab')
files_mod = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
colab.files = files_mod
google = types.ModuleType('google')
google.colab = colab
sys.modules['google'] = google
sys.modules['google.colab'] = colab


def run(i: int, source: str | None = None, label: str = '') -> dict:
    code = source if source is not None else src[i]
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(code, f'<cell {i}>', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {str(exc)[:400]}'
            buf.write(traceback.format_exc()[-1200:])
    out = buf.getvalue()
    rec = {'cell': i, 'label': label, 'seconds': round(time.perf_counter() - t0, 1), 'error': err, 'stdout_tail': out[-2500:]}
    print(f'[{label or i}] cell {i} {rec["seconds"]}s err={err}', file=sys.stderr, flush=True)
    return rec


# ---------------- P4 (part2): BYOD group-count boundary ----------------
if PART2:
    import numpy as np
    for i in (3, 5, 7, 9):
        assert run(i, label='P4 setup')['error'] is None
    corpus = ns['read_corpus'](ns['fetch_corpus'](cache_dir='weights/diode-sample'))
    views = corpus[:8]
    c13 = src[13].replace('USE_BYOD = False', 'USE_BYOD = True')
    p4 = {}
    for n_groups in (1, 3, 4):
        recs = [{**v, 'scan': f'g{k % n_groups}'} for k, v in enumerate(views)]
        buf = io.BytesIO(); rows = ['id,image,depth,mask,group']
        with zipfile.ZipFile(buf, 'w') as zf:
            for r in recs:
                ib = io.BytesIO(); r['image'].save(ib, format='PNG'); zf.writestr(f"{r['id']}.png", ib.getvalue())
                db = io.BytesIO(); np.save(db, np.asarray(r['depth'], dtype=np.float32)); zf.writestr(f"{r['id']}_d.npy", db.getvalue())
                mb = io.BytesIO(); np.save(mb, np.asarray(r['mask'], dtype=bool)); zf.writestr(f"{r['id']}_m.npy", mb.getvalue())
                rows.append(f"{r['id']},{r['id']}.png,{r['id']}_d.npy,{r['id']}_m.npy,{r['scan']}")
            zf.writestr('records.csv', '\n'.join(rows) + '\n')
        UPLOAD.clear(); UPLOAD['byod.zip'] = buf.getvalue()
        rec = run(13, c13, f'P4 {n_groups} groups')
        rec['split_sizes'] = {k: len(v) for k, v in ns.get('splits', {}).items()} if rec['error'] is None else None
        p4[f'8_views_{n_groups}_groups'] = rec
    results['P4_byod_groups'] = p4
    results['finished'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    save()
    sys.exit(0)

# ---------------- P1 clean default ----------------
import torch, transformers, numpy, PIL  # noqa: E402,E401
results['environment'] = {
    'python': sys.version.split()[0], 'torch': torch.__version__, 'transformers': transformers.__version__,
    'numpy': numpy.__version__, 'pillow': PIL.__version__, 'threads': torch.get_num_threads(), 'device': 'cpu',
    'note': 'build venv dimer-next16 = PINS; CUDA hidden; install cell skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1',
}
p1 = []
for i in results['P0_static']['code_cells']:
    p1.append(run(i, label='P1'))
    if p1[-1]['error']:
        break
results['P1_default'] = {'cells': p1, 'all_ok': all(r['error'] is None for r in p1)}
if results['P1_default']['all_ok']:
    ar = ns['adapt_result']
    results['P1_default']['observed'] = {
        'history': [(h['epoch'], h['stage'], h['val']['abs_rel'] if h['val'] else None) for h in ar['history']],
        'policy': ar['policy'], 'best_epoch': ar['best_epoch'], 'comparison': ns['comparison'],
        'reload_parity': ns['parity'], 'outputs': sorted(os.listdir('outputs')),
    }
save()

# ---------------- P2 active learning: documented experiment LEARNING_RATE = 3e-5 ----------------
if results['P1_default']['all_ok']:
    before_val = ns['adapt_result']['history'][ns['adapt_result']['best_epoch']]['val']['abs_rel']
    c19 = src[19].replace('LEARNING_RATE = 1e-5', 'LEARNING_RATE = 3e-5')
    assert c19 != src[19]
    p2 = [run(19, c19, 'P2 lr=3e-5'), run(21, label='P2'), run(23, label='P2')]
    ar = ns.get('adapt_result', {})
    results['P2_experiment_lr3e-5'] = {
        'cells': p2,
        'selected_val_abs_rel_from_P1': before_val,
        'history': [(h['epoch'], h['stage'], h['val']['abs_rel'] if h['val'] else None) for h in ar.get('history', [])],
        'policy': ar.get('policy'), 'best_epoch': ar.get('best_epoch'),
        'documented_expectation': 'build record: neck-and-head policy wins at epoch 2, held-out 0.175 (from the untouched checkpoint)',
    }
    save()

# ---------------- P3 BYOD and recovery ----------------
import numpy as np  # noqa: E402


def make_zip(records, *, group=True, name='byod.zip') -> tuple[str, bytes]:
    buf = io.BytesIO()
    rows = ['id,image,depth,mask,group' if group else 'id,image,depth,mask']
    with zipfile.ZipFile(buf, 'w') as zf:
        for r in records:
            ib = io.BytesIO(); r['image'].save(ib, format='PNG'); zf.writestr(f"{r['id']}.png", ib.getvalue())
            db = io.BytesIO(); np.save(db, np.asarray(r['depth'], dtype=np.float32)); zf.writestr(f"{r['id']}_d.npy", db.getvalue())
            mb = io.BytesIO(); np.save(mb, np.asarray(r['mask'], dtype=bool)); zf.writestr(f"{r['id']}_m.npy", mb.getvalue())
            g = f",{r.get('scan', r['id'])}" if group else ''
            rows.append(f"{r['id']},{r['id']}.png,{r['id']}_d.npy,{r['id']}_m.npy{g}")
        zf.writestr('records.csv', '\n'.join(rows) + '\n')
    return name, buf.getvalue()


if results['P1_default']['all_ok']:
    base = list(ns['train_records']) + list(ns['val_records']) + list(ns['test_records'])
    c13 = src[13].replace('USE_BYOD = False', 'USE_BYOD = True')
    p3 = {}
    UPLOAD.clear(); UPLOAD.update(dict([make_zip(base)]))
    p3['valid_40_views_grouped'] = run(13, c13, 'P3 byod valid')
    if p3['valid_40_views_grouped']['error'] is None:
        p3['section6_after_byod_rerun'] = run(17, label='P3 sec6 rerun')
        zs = ns.get('zero_shot_test', {})
        p3['section6_after_byod_rerun']['zero_shot_test_policy_field'] = zs.get('policy')
        p3['section6_after_byod_rerun']['zero_shot_test_adapted_field'] = zs.get('adapted')
    UPLOAD.clear(); UPLOAD.update(dict([make_zip(base[:8], group=False)]))
    p3['invalid_no_group_column'] = run(13, c13, 'P3 no group')
    UPLOAD.clear()
    p3['invalid_upload_cancelled_empty'] = run(13, c13, 'P3 empty upload')
    UPLOAD.clear(); UPLOAD.update({'notes.txt': b'not a zip'})
    p3['invalid_not_a_zip'] = run(13, c13, 'P3 not zip')
    results['P3_byod'] = p3
    save()

results['finished'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
save()
print('done', file=sys.stderr)
